const express = require('express');
const session = require('express-session');
const path = require('path');
const fs = require('fs').promises;
const bodyParser = require('body-parser');
// 新增：引入文件上传中间件
const multer = require('multer');
const app = express();

// 新增：配置文件存储（需先执行 npm install multer）
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        const uploadPath = path.join(__dirname, 'data', 'photos');
        fs.mkdir(uploadPath, { recursive: true }).then(() => cb(null, uploadPath));
    },
    filename: function (req, file, cb) {
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
        cb(null, uniqueSuffix + '-' + file.originalname);
    }
});
const upload = multer({ storage: storage });

// 新增：照片上传接口（需配合前端表单使用FormData提交）
app.post('/api/upload/photos', upload.fields([
    { name: 'leftPhoto', maxCount: 1 },
    { name: 'rightPhoto', maxCount: 1 },
    { name: 'frontPhoto', maxCount: 1 }
]), async (req, res) => {
    try {
        if (!req.files) {
            return res.status(400).json({ success: false, message: '未上传照片' });
        }
        
        // 这里可以将文件路径关联到人员信息（需配合人员提交接口使用）
        const photoPaths = Object.keys(req.files).reduce((acc, key) => {
            acc[key] = `/data/photos/${req.files[key][0].filename}`;
            return acc;
        }, {});

        res.json({ success: true, photoPaths });
    } catch (error) {
        console.error('照片上传失败:', error);
        res.status(500).json({ success: false, message: '照片上传失败' });
    }
});

// 中间件配置
app.use(bodyParser.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));
// 新增data文件夹作为静态资源
app.use('/data', express.static(path.join(__dirname, 'data')));

// 会话配置
app.use(session({
    secret: 'your-secret-key',
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false }
}));

// 认证中间件
const authCheck = (req, res, next) => {
    const allowedPaths = ['/login.html', '/forgot_password.html', '/login'];
    if (!req.session.loggedIn && !allowedPaths.includes(req.path)) {
        return res.redirect('/login.html');
    }
    next();
};
app.use(authCheck);

// 登录API
app.post('/login', async (req, res) => {
    const { username, password } = req.body;
    try {
        const credentialsPath = path.join(__dirname, 'data', 'credentials.json');
        const rawData = await fs.readFile(credentialsPath, 'utf-8');
        const users = JSON.parse(rawData);

        const matchedUser = users.find(
            user => user.username === username && user.password === password
        );

        if (matchedUser) {
            req.session.loggedIn = true;
            req.session.user = {
                name: matchedUser.name,
                policeId: matchedUser.policeId,
                idCard: matchedUser.idCard
            };
            res.json({ success: true, user: req.session.user });
        } else {
            res.status(401).json({ success: false, message: '账号或密码错误' });
        }
    } catch (error) {
        console.error('登录验证出错:', error);
        res.status(500).json({ success: false, message: '服务器内部错误' });
    }
});

// 案件API路由
const casesDataPath = path.join(__dirname, 'data', 'cases.json');

// 获取所有案件
app.get('/api/cases', async (req, res) => {
    try {
        const data = await fs.readFile(casesDataPath, 'utf-8');
        try {
            res.json(JSON.parse(data));
        } catch (parseError) {
            console.error('JSON解析错误:', parseError);
            res.status(500).json({ error: '案件数据格式错误，请联系管理员' });
        }
    } catch (error) {
        if (error.code === 'ENOENT') {
            res.json([]);
        } else {
            console.error('获取案件列表失败:', error);
            res.status(500).json({ error: '获取案件列表失败' });
        }
    }
});

// 创建新案件
app.post('/api/cases', async (req, res) => {
    try {
        let cases = [];
        try {
            const data = await fs.readFile(casesDataPath, 'utf-8');
            cases = JSON.parse(data);
        } catch (err) {
            if (err.code !== 'ENOENT') throw err;
        }

        // 新增：确保 caseStatus 存在（前端未传时默认设为"处理中"）
        const newCase = { 
            ...req.body, 
            caseStatus: req.body.caseStatus || '处理中' 
        };
        cases.push(newCase);

        await fs.writeFile(casesDataPath, JSON.stringify(cases, null, 2));
        res.json({ success: true });
    } catch (error) {
        console.error('案件保存失败:', error);
        res.status(500).json({ success: false, message: '案件保存失败' });
    }
});

// 获取单个案件
app.get('/api/cases/:caseNumber', async (req, res) => {
    try {
        const data = await fs.readFile(casesDataPath, 'utf-8');
        const cases = JSON.parse(data);
        const caseItem = cases.find(c => c.caseNumber === req.params.caseNumber);
        
        if (caseItem) {
            res.json(caseItem);
        } else {
            res.status(404).json({ error: '案件不存在' });
        }
    } catch (error) {
        console.error('获取案件详情失败:', error);
        res.status(500).json({ error: '获取案件详情失败' });
    }
});

// 删除案件
app.delete('/api/cases/:caseNumber', async (req, res) => {
    try {
        const data = await fs.readFile(casesDataPath, 'utf-8');
        let cases = JSON.parse(data);
        const initialLength = cases.length;
        
        cases = cases.filter(c => c.caseNumber !== req.params.caseNumber);
        
        if (cases.length === initialLength) {
            return res.status(404).json({ success: false, message: '案件不存在' });
        }
        
        await fs.writeFile(casesDataPath, JSON.stringify(cases, null, 2));
        res.json({ success: true });
    } catch (error) {
        console.error('删除案件失败:', error);
        res.status(500).json({ success: false, message: '删除案件失败' });
    }
});

// 人员管理API
const personnelDataPath = path.join(__dirname, 'data', 'personnel.json');

// 修改：创建人员记录时关联照片路径（需前端提交时包含photoPaths）
app.post('/api/personnel', async (req, res) => {
    try {
        let personnel = [];
        try {
            const data = await fs.readFile(personnelDataPath, 'utf-8');
            personnel = JSON.parse(data);
        } catch (err) {
            if (err.code !== 'ENOENT') throw err;
        }

        // 新增：如果是嫌疑人，添加照片路径信息
        if (req.body.personType === 'suspect') {
            personnel.push({ ...req.body, photos: req.body.photoPaths });
        } else {
            personnel.push(req.body);
        }

        await fs.writeFile(personnelDataPath, JSON.stringify(personnel, null, 2));
        res.json({ success: true });
    } catch (error) {
        console.error('人员信息保存失败:', error);
        res.status(500).json({ success: false, message: '人员信息保存失败' });
    }
});

// 启动服务器
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`服务器运行在 http://localhost:${PORT}`);
});

// 更新案件
app.put('/api/cases/:caseNumber', async (req, res) => {
    try {
        const data = await fs.readFile(casesDataPath, 'utf-8');
        let cases = JSON.parse(data);
        
        // 查找要更新的案件索引
        const index = cases.findIndex(c => c.caseNumber === req.params.caseNumber);
        if (index === -1) {
            return res.status(404).json({ success: false, message: '案件不存在' });
        }

        // 创建新对象保留原有registrationTime
        const updatedCase = { 
            ...cases[index],
            ...req.body,
            registrationTime: cases[index].registrationTime // 保留原始登记时间
        };

        cases[index] = updatedCase;

        // 使用格式化写入防止JSON损坏
        async function safeWriteFile(path, data) {
            // 验证JSON格式有效性
            try {
                JSON.parse(JSON.stringify(data));
            } catch (e) {
                throw new Error('无效的JSON格式');
            }
            await fs.writeFile(path, JSON.stringify(data, null, 2));
        }
        
        // 调用安全写入函数
        await safeWriteFile(casesDataPath, cases);
        
        res.json({ success: true });
    } catch (error) {
        console.error('更新案件失败:', error);
        res.status(500).json({ success: false, message: '服务器内部错误' });
    }
});

// 添加人员删除接口
app.delete('/api/personnel/:idCard', async (req, res) => {
    try {
        const idCard = req.params.idCard;
        let personnel = [];
        const data = await fs.readFile(personnelDataPath, 'utf-8');
        personnel = JSON.parse(data);
        
        const originalLength = personnel.length;
        personnel = personnel.filter(p => p.idCard !== idCard);
        
        if (originalLength === personnel.length) {
            return res.status(404).json({ success: false, message: '未找到该人员' });
        }
        
        await fs.writeFile(personnelDataPath, JSON.stringify(personnel, null, 2));
        res.json({ success: true, message: '删除成功' });
    } catch (error) {
        console.error('删除人员失败:', error);
        res.status(500).json({ success: false, message: '删除人员失败' });
    }
});

// 获取单个人员
app.get('/api/personnel/:idCard', async (req, res) => {
    try {
        const data = await fs.readFile(personnelDataPath, 'utf-8');
        const personnel = JSON.parse(data);
        const person = personnel.find(p => p.idCard === req.params.idCard);
        
        if (person) {
            res.json(person);
        } else {
            res.status(404).json({ error: '人员不存在' });
        }
    } catch (error) {
        console.error('获取人员详情失败:', error);
        res.status(500).json({ error: '获取人员详情失败' });
    }
});

// 警械管理API
const equipmentDataPath = path.join(__dirname, 'data', 'equipment.json');

// 获取所有警械
app.get('/api/equipment', async (req, res) => {
    try {
        const data = await fs.readFile(equipmentDataPath, 'utf-8');
        res.json(JSON.parse(data));
    } catch (error) {
        if (error.code === 'ENOENT') {
            res.json([]);
        } else {
            console.error('获取警械列表失败:', error);
            res.status(500).json({ error: '获取警械列表失败' });
        }
    }
});

// 添加新警械
app.post('/api/equipment', async (req, res) => {
    try {
        let equipment = [];
        try {
            const data = await fs.readFile(equipmentDataPath, 'utf-8');
            equipment = JSON.parse(data);
        } catch (err) {
            if (err.code !== 'ENOENT') throw err;
        }

        const newEquipment = {
            id: Date.now().toString(),
            name: req.body.name,
            type: req.body.type,
            issueDate: new Date().toISOString(),
            status: '正常'
        };
        equipment.push(newEquipment);

        await fs.writeFile(equipmentDataPath, JSON.stringify(equipment, null, 2));
        res.json({ success: true });
    } catch (error) {
        console.error('添加警械失败:', error);
        res.status(500).json({ success: false, message: '添加警械失败' });
    }
});

// 报废警械
app.delete('/api/equipment/:id', async (req, res) => {
    try {
        const data = await fs.readFile(equipmentDataPath, 'utf-8');
        let equipment = JSON.parse(data);
        
        const index = equipment.findIndex(e => e.id === req.params.id);
        if (index === -1) {
            return res.status(404).json({ success: false, message: '警械不存在' });
        }

        // 更新状态为已报废
        equipment[index].status = '已报废';
        
        await fs.writeFile(equipmentDataPath, JSON.stringify(equipment, null, 2));
        res.json({ success: true });
    } catch (error) {
        console.error('报废警械失败:', error);
        res.status(500).json({ success: false, message: '报废警械失败' });
    }
});